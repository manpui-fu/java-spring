# springsecuritydemo  
使用javaconfig的方式整合SpringMVC+Mybatis+SpringSecurity实现基于数据库的权限系统，包括对按钮的权限控制。  
详情请到http://blog.csdn.net/poorcoder_/article/details/70231779
