package com.study.model;
/**
 * 用于前台资源列表展示  
 * @author Administrator
 *
 */
public class RResources extends Resources{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String checked;//是否选中

	public String getChecked() {
		return checked;
	}

	public void setChecked(String checked) {
		this.checked = checked;
	}
	
	
	

}
